Config = {}
Config.SellPrice = 150
Config.NumberOfSellOneTime = 1
Config.AliveToSlaughter = 1
Config.SlaughterToPack = 1

Config.SellLocation = {
    pos = { x = -873.2886, y = -2735.228, z = 13.5}
}


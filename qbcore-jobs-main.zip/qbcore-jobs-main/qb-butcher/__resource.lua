resource_manifest_version "44febabe-d386-4d18-afbe-5e627f4af937"

description 'Pepe Butcher'

server_scripts {
	'config.lua',
	'server/server.lua',
	'server/butcher.lua'
}

client_scripts {
	'config.lua',
	'client/client.lua',
	'client/butcher.lua'
}
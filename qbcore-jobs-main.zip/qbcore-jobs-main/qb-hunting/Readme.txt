-- Images for inventory are in the img folder these go in qb_inventory/html/images

-- Add these to core/share.lua
["meat"] 						 = {["name"] = "meat", 			  	  			["label"] = "Vension", 					["weight"] = 100, 		["type"] = "item", 		["image"] = "meat.png", 	    	["unique"] = false, 	["useable"] = true, 	["shouldClose"] = true,	   ["combinable"] = nil,   ["description"] = "Deer Venison"},
["leather"] 					 = {["name"] = "leather", 			  			["label"] = "Leather", 					["weight"] = 100, 		["type"] = "item", 		["image"] = "leather.png", 		    ["unique"] = false, 	["useable"] = true, 	["shouldClose"] = true,	   ["combinable"] = nil,   ["description"] = "Deer Leather"},
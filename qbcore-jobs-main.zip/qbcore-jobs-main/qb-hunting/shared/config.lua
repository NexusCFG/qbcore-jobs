Config = {}

Config.Hunting = {
	vec(-1492.86, 4971.34, 63.91)
}

Config.Butcher = {
	vec(-66.8, 6237.96, 31.09)
}

Config.HuntWeapons = {
	GetHashKey("weapon_knife"),
   }